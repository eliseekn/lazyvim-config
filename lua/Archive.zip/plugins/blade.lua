return {
  {
    "jwalton512/vim-blade",
    ft = "blade", -- Only load the plugin when editing blade files
  },
}
