return {
  "greggh/claude-code.nvim",
  dependencies = {
    "nvim-lua/plenary.nvim", -- Required for git operations
  },
  cmd = "ClaudeCode",
  keys = { { "<leader>C", "<cmd>ClaudeCode<cr>", desc = "Claude code" } },
  config = function()
    require("claude-code").setup({
      window = {
        position = "float",
      },
    })
  end,
}
